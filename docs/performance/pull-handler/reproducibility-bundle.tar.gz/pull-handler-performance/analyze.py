"""Aggregate pinned final binaries; keep the original matrix separate from repeats."""
import gzip
import collections
import csv
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
VARIANTS = ("ref2443", "ref2473", "candidate1")
TIMING_IDS = dict(zip(VARIANTS, (
    "ref2443-7c34c9d40c6d10b8",
    "ref2473-b5a045eb603f113a",
    "candidate1-deed2d1cc020f96a",
)))
METRICS = (
    "wall_ms", "cpu_ms", "tick_max_us", "tick_p95_us", "arrival_p95_us",
    "emission_to_consumer_p95_us", "prime_ms", "prime_tick_max_us",
    "setup_inclusive_ms", "setup_inclusive_cpu_ms", "events", "source_polls",
    "max_source_ahead", "log_bytes", "log_serialize_ms", "allocations",
    "allocated_bytes", "peak_phase_bytes", "live_after_driver_drop_bytes",
)


def write_summary(filename, rows):
    groups = collections.defaultdict(list)
    for row in rows:
        groups[row["config"]["name"], row["variant"]].append(row)
    fields = ["workload", "variant", "identity", "samples"]
    fields += [f"{metric}_{stat}" for metric in METRICS for stat in ("median", "min", "max")]
    with (RESULTS / filename).open("w") as output:
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        for (name, variant), samples in sorted(groups.items()):
            result = dict(workload=name, variant=variant, identity=samples[0]["identity"], samples=len(samples))
            for metric in METRICS:
                values = [sample[metric] for sample in samples]
                for label, function in (("median", statistics.median), ("min", min), ("max", max)):
                    result[f"{metric}_{label}"] = function(values)
            writer.writerow(result)
    return groups


def main():
    allocation_ids = json.loads((RESULTS / "final-selection.json").read_text())["allocation_identities"]
    identities = set(TIMING_IDS.values()) | set(allocation_ids.values())
    metadata = {}
    for identity in sorted(identities):
        data = json.loads((RESULTS / f"{identity}.build.json").read_text())
        metadata[identity] = data
    rows = [json.loads(line) for line in gzip.open(RESULTS / "samples.jsonl.gz", "rt")]
    selected = [row for row in rows if row["identity"] in identities]
    keys = set()
    for row in selected:
        key = row["identity"], row["config_sha256"], row["repetition"]
        assert key not in keys
        keys.add(key)
        assert row["verified"]
        assert row["binary_sha256"] == metadata[row["identity"]]["binary_sha256"]
        config = ROOT / "configs" / (row["config"]["name"] + ".json")
        assert hashlib.sha256(config.read_bytes()).hexdigest() == row["config_sha256"]
        supplied = json.loads(config.read_text())
        assert all(row["config"][key] == value for key, value in supplied.items())
    timing = [row for row in selected if row["identity"] in TIMING_IDS.values()]
    initial = [row for row in timing if row["repetition"] < 5]
    groups = write_summary("final-timing-summary.csv", initial)
    assert len(groups) == 88 * 3 and all(len(samples) == 5 for samples in groups.values())
    for name in {name for name, _ in groups}:
        expanded = {json.dumps(row["config"], sort_keys=True) for variant in VARIANTS for row in groups[name, variant]}
        assert len(expanded) == 1, name
    allocations = [row for row in selected if row["identity"] in allocation_ids.values()]
    allocation_groups = write_summary("final-allocation-summary.csv", allocations)
    assert len(allocation_groups) == 88 * 3
    repeated_names = {row["config"]["name"] for row in timing if row["repetition"] >= 5}
    write_summary("focused-repeat-summary.csv", [row for row in timing if row["config"]["name"] in repeated_names])
    unequal = []
    for name in {name for name, _ in groups}:
        if any(groups[name, variant][0]["config"]["workload"].startswith(("cancel_", "sparse")) for variant in VARIANTS):
            continue
        outcomes = {(row["events"], tuple(row["output_checksums"])) for variant in VARIANTS for row in groups[name, variant]}
        if len(outcomes) != 1:
            unequal.append(name)
    assert not unequal, unequal
    (RESULTS / "final-selection.json").write_text(json.dumps({
        "timing_identities": TIMING_IDS, "allocation_identities": allocation_ids,
        "initial_timing_samples": len(initial), "allocation_samples": len(allocations),
        "additional_timing_samples": len(timing) - len(initial),
        "full_work_output_mismatches": unequal,
        "note": "Schema/output checks are not proof that performance targets passed. See REPORT.md.",
    }, indent=2) + "\n")
    print(f"Validated {len(initial)} initial timings, {len(allocations)} allocation samples, {len(timing)-len(initial)} additional timings.")


if __name__ == "__main__":
    main()
