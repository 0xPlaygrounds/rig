# Owned replies: performance follow-up

The selected implementation retains #2473's owned `Reply` API and drives streams
on the existing executor through a private bounded receiver. Collection permits
64 queue checks per effect and 4,096 across a whole host tick, including repeated
quiescence passes. A rotating effect cursor preserves progress. This removes the
severe measured burst and native frame regressions without restoring unbounded
draining. **Paced ECS latency at 240 Hz misses the target set before tuning.** Following
the user’s direction to prefer the minimal design when it is an overall
improvement, retain the executor policy and disclose that latency cost. The
large throughput/frame improvements justify the choice; it is not a win on
every metric. Repository verification and PR publication remain unfinished.

## Evidence and reproduction

Run `python3 analyze.py` from this directory (or invoke it by absolute path).
The workspace analyzer verifies local binary and config hashes, distinct sample keys, completed workload
coverage, matching expanded inputs, and full-work event/checksum equality, then
regenerates the three summary CSVs. The harness additionally validates actual
outcomes, block identity/text/order, provider output, recording headers and replay-plan registration. Full replay execution is covered by the
separate correctness suites.
Fixed-time cancellation/sparse prefixes are intentionally excluded from the
cross-run equal-completed-work assertion; each sample still passes its own checks.

The initial matrix contains 1,320 timing samples: 88 unchanged workloads, three
variants, five repetitions. Allocation instrumentation runs separately: 264
samples, one per workload/variant. Three borderline cases received 15 additional
timing repetitions per variant (135 samples); their 20-run summaries are separate
from the original five-run matrix. Raw rows remain append-only in
`results/samples.jsonl`. See `results/final-selection.json` for exact selected
identities; historical/prototype rows must not be mixed into the final matrix.

Timing identities:

- #2443: `ref2443-7c34c9d40c6d10b8`, source revision
  `36436398d0ef00fc99ef260b0a941775ac588c22`.
- Original #2473: `ref2473-b5a045eb603f113a`, source revision
  `719fdc8b912837c7779023733feab20bbb269f48`.
- Candidate: `candidate1-deed2d1cc020f96a`, that #2473 revision plus the
  follow-up working changes captured in `sources/candidate1` and per-file build
  hashes. The production runtime sources match this snapshot. Subsequent test-only lint and writer-generated replay-fixture
  corrections do not affect its runtime binary.

The corresponding `results/<identity>.build.json` records source/harness hashes,
full binary SHA-256, compiler, features, build command and target directory.
`build.py` builds preserved source snapshots; `run.py` runs matching binaries
against the original sibling `pr-performance/configs` and resumes only identical
binary/config/repetition keys. The portable archive `results/reproducibility-bundle.tar.gz` includes a separate
README, preparation/build/run scripts, preserved configs and byte-identical
fixtures. Its source reconstruction was executed and every recorded source hash
matched for all three variants. Its analyzer verifies archived row/metadata and
config hashes; it cannot hash executable files, which are not distributed. New
runs relocate fixture paths into separate configs without changing archived
inputs. See the archive README for exact commands.

Runs used Rust 1.95.0 on an M2 Max with repository release settings. Variants ran
sequentially in alternating order, without this task's builds/tests during
timings. The machine was not exclusive: an unrelated long-running test was
observed during the initial matrix. See `results/measurement-environment.json`.
The repeat block exhibited greater paced latency across executor-based variants.
Do not attribute that change to one cause without diagnostic evidence. Summary
CSVs include min/median/max; these are machine-specific experiments, not SLAs.

## Initial matrix results

Medians of five runs; tick figures are medians of each run's maximum.

| Workload / metric | #2443 | Original #2473 | Candidate |
|---|---:|---:|---:|
| One ready ECS stream, completion ms | 0.251 | 6.969 | 0.361 |
| 64 ready streams at 60 Hz, completion ms | 24.345 | 2,135.594 | 37.842 |
| 1,024 ready streams, maximum tick ms | 97.064 | 13.622 | 9.817 |
| Heavy streamed verdict, maximum tick ms | 0.382 | 67.503 | 0.328 |
| OpenAI 4 KiB at 60 Hz, completion ms | 203.843 | 5,270.274 | 203.607 |
| Sparse 4,096 streams at 1 kHz, CPU ms | 69.155 | 146.898 | 73.451 |
| Paced 64 streams at 60 Hz, CPU ms | 18.715 | 8.065 | 17.279 |
| Agent writer 64, completion ms | 7.967 | 12.881 | 12.222 |
| Agent four layers/event recording, completion ms | 13.902 | 10.203 | 10.255 |

The burst targets (1/100/300 ms), heavy-verdict target (8 ms) and 1,024-stream
tick target (16 ms) pass. No heavy-verdict sample exceeded 16 ms; the largest was
0.501 ms. Sparse CPU is 1.062 times #2443, below the 1.25 investigation threshold.
All 88 allocation comparisons remain below 1.25 times the larger reference's
peak phase heap. This does not equate heap to RSS or bound retained ECS output. At 1,024 ready
streams the candidate uses 316.218 ms total CPU versus #2443’s 286.310 ms and
original #2473’s 224.470 ms, while completion improves to 140.964 ms from original
#2473’s 222.982 ms. Bounded collection trades total scheduling work for shorter
host ticks; this is another cost of the selected policy.

Paced ECS CPU gives up original #2473's inline-polling saving while recovering
worker isolation and burst throughput. At 60 Hz completion and p95 arrival
latency remain within one host tick of the better reference. At 240 Hz the
initial candidate p95 arrival is 8.423 ms versus 4.142 ms: a 4.280 ms gap, narrowly
outside the 4.167 ms allowance. That prompted the repeats below.

The direct bounded-drain prototype recovered bursts but retained a roughly
66 ms heavy-verdict tick. Executor driving without a global collection bound
retained long high-concurrency ticks. Adding the global bound and using the
receiver directly reduced those costs; preserved prototype samples document
that choice. No public batch API, scheduler modes, adaptive prefetch or wake
registry was added.

## Repeat investigation and the minimal-design decision

The small `agent-ready-1` case initially appeared 19.5% slower than original
#2473. Across 20 runs the candidate median is 0.159 ms versus 0.162 ms: the
apparent regression does not repeat. No other agent direct/layer case crossed
the initial 15% investigation threshold.

Across 20 runs, ECS paced 240 Hz p95 arrival is 11.506 ms versus original
#2473's 4.295 ms, a **7.211 ms gap against a 4.167 ms allowance**. #2443 is also
slower at 10.740 ms. Candidate completion is 489.293 ms versus 482.445 ms,
also outside one tick. This experimental target has not passed. Keep that result in the report even
though the overall design decision favors the minimal executor policy.

Comparing the initial five samples with the next fifteen, candidate arrival p95
rises from 8.423 to 11.609 ms, and emission-to-consumer p95 from 4.295 to 5.401 ms.
#2443 arrival rises from 7.605 to 10.823 ms; all agent variants also show increased
arrival latency. Original #2473's inline ECS polling stays near one tick.
This supports investigating timer/worker scheduling and host deadline lateness;
it does not establish timer behavior as the sole cause. Percentiles cannot be
subtracted to recover a production-lateness percentile.

A separate five-run diagnostic now measures paired per-event emission-minus-due
and per-tick start-minus-deadline. At 240 Hz, candidate production lateness p95
is 8.906 ms, #2443 is 8.729 ms, and inline #2473 is 4.432 ms. Host deadline
lateness p95 is similar across variants (1.727–1.855 ms). Candidate
emission-to-consumer p95 is 5.642 ms, versus #2443’s 4.177 ms and inline #2473’s
0.745 ms. Late event production and the extra collection boundary both contribute;
this does not prove a timer-library defect. The diagnostic uses separate binaries
and is not substituted for the original timing matrix.

The user directed that the minimal design is preferable provided it is an
overall improvement. Retain this single executor policy: it removes multi-second
burst regressions and 67 ms native collection stalls, restores sparse CPU near
#2443, and preserves direct/layer agent performance. Adding a second polling
mode or scheduler solely to close this synthetic 240 Hz gap would increase
machinery and could reintroduce expensive work on the host. The failed latency
criterion remains an explicit tradeoff, alongside paced CPU and the retained
writer overhead. This is an aggregate design judgment, not universal speedup.

## Writer, lifetime and verification

The writer change drains adapter output directly across awaited sends, removing
a temporary vector. Isolated three-sample allocation measurements reduce agent
64-writer allocation count from 118,342 to 101,898 and allocated bytes from
23,924,617 to 17,477,149; peak heap is effectively unchanged. It preserves the
writing future through post-finish work. The candidate remains about 1.53 times
#2443's writer completion time in the final matrix. The allocation improvement
does not eliminate the helper's residual throughput cost.

Independent code review found and verified a replay-prefix regression fix:
implicitly cancelled replay streams must stop source polling before synthesized
fallback errors, retain ownership, and await policy cancellation. A separate
native race regression proves that callbacks from a returning worker poll cannot
mutate a recording already closed by cancellation. Browser tests exposed missing
Bevy web executor feature wiring; executed Firefox tests then passed pending
setup, unary folding, idle/full-queue cancellation without later host ticks.

Current affected-package verification: 2,764 tests passed, two configured skips;
strict affected-package Clippy passed. The complete PR gate is running against
`origin/feat/effect-bus` and must finish before publication. An earlier run caught
a hand-minted ID in the new replay fixture. The fixture now records every
writer-generated prefix event and its actual delivery count; the source guard
and integration regression pass, and independent review verified the correction. Independent benchmark
review confirms the main results and the measured 240 Hz miss. Its final review
of the diagnostic and design rationale is pending.
No commit, push, PR mutation or goal-completion claim has been made for this
follow-up.
