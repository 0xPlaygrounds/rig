//! Opt-in thread-placement diagnostics, excluded from timed builds.
#[cfg(feature = "diagnostic")]
fn observations() -> &'static std::sync::Mutex<std::collections::BTreeMap<String, std::collections::BTreeMap<String, usize>>> {
    static CALLS: std::sync::OnceLock<std::sync::Mutex<std::collections::BTreeMap<String, std::collections::BTreeMap<String, usize>>>> = std::sync::OnceLock::new();
    CALLS.get_or_init(Default::default)
}

#[inline]
pub fn record(stage: &'static str) {
    #[cfg(feature = "diagnostic")]
    {
        let thread = format!("{:?}", std::thread::current().id());
        *observations().lock().unwrap().entry(stage.to_owned()).or_default().entry(thread).or_default() += 1;
    }
    #[cfg(not(feature = "diagnostic"))]
    let _ = stage;
}

pub fn snapshot() -> serde_json::Value {
    #[cfg(feature = "diagnostic")]
    { serde_json::to_value(&*observations().lock().unwrap()).unwrap() }
    #[cfg(not(feature = "diagnostic"))]
    { serde_json::Value::Null }
}
