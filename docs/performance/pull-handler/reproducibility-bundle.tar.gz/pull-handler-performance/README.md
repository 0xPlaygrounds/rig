# Reproduce the owned-reply performance comparison

This bundle contains the shared benchmark, all 88 workload inputs, offline SSE
fixtures, exact source reconstruction inputs, build metadata, compressed raw
samples and summaries. `REPORT.md` explains the result and its limitations.
The candidate's measured runtime is the performance follow-up to #2473; its
snapshot predates two test-only fixture/lint corrections in the final PR.

Inspect existing results without Rust or a checkout:

```sh
python3 analyze.py
```

This validates archived metadata/config identity and completed-work checks and
regenerates the CSVs. It does not reexecute a binary. Raw data includes 1,320
initial timing samples, 264 allocation samples, 135 focused repeat timings and
45 separate pacing diagnostics. Diagnostic results must not be mixed into the
timing matrix. The initial CSV uses repetitions 0–4; the focused CSV uses all
20 repetitions of its three cases. Metadata includes full source and binary
hashes. Original executable binaries are not distributed.

To rebuild, use a local clone of `https://github.com/0xPlaygrounds/rig` containing
the two full revisions in `references.json`. Run from an extracted bundle:

```sh
python3 prepare.py /absolute/path/to/rig
# If dependency packages are not cached, run `cargo fetch --locked` in each
# sources/ref2443, sources/ref2473 and sources/candidate1 directory first.
python3 build.py ref2443 ref2473 candidate1
python3 run.py ref2443,ref2473,candidate1 --repetitions 5
python3 run.py ref2443,ref2473,candidate1 --repetitions 20 agent-ready-1 ecs-paced-64-240hz agent-paced-64-240hz
python3 build.py --alloc ref2443 ref2473 candidate1
python3 run.py ref2443-alloc,ref2473-alloc,candidate1-alloc --repetitions 1
python3 build.py --latency ref2443 ref2473 candidate1
python3 run.py ref2443-latency,ref2473-latency,candidate1-latency --repetitions 5 ecs-paced-64-240hz ecs-paced-64-60hz agent-paced-64-240hz
```

`prepare.py` creates detached shared clones and refuses to overwrite existing
source directories. It does not change the supplied repository. Keep that
repository available while using the shared clones. It applies the measured
candidate patch, includes the new sibling tests, installs the shared benchmark
and exact dependency locks, and checks every recorded source hash. This source
reconstruction has been executed and verified for all three variants.

The original configs retain their historical absolute fixture paths for hash
verification. Preparation writes separate `run-configs` with only those paths
relocated to bundled, byte-identical fixtures. New runs therefore have new config
hashes; the original rows remain in `results/samples.jsonl.gz`, and new results
append to `results/samples.jsonl`. New build identities reflect their actual
binaries. Different build paths/toolchains/platforms may change binary hashes.

The repository pins Rust 1.95.0. Use the same release profile and dependency lock;
builds invoke Cargo offline after dependencies are cached. Build targets are
under `/tmp/rig-perf-followup-<variant>-target`. Run one build/measurement command
at a time and keep builds/tests out of timing windows. The runner alternates
variant order and validates output on every run. These desktop measurements
are not general latency guarantees. See the min/median/max columns and the
documented 240 Hz latency and paced CPU tradeoffs.

`SHA256SUMS.json` covers the shipped evidence files. Generated sources, binaries,
run configs and new samples are excluded from the distributed archive.

The `exploratory` directory also preserves source overlays for bounded direct
draining, executor transport, global budgeting, receiver storage, and the isolated
writer optimization. Apply each overlay to a detached original #2473 checkout;
it includes that candidate's benchmark under `examples/protocol_perf`. Use
`cargo build --release --offline -p protocol-perf --features pull` (add `alloc`
for allocation measurements), then run the executable with a relocated config.
`results/all-experiment-samples.jsonl.gz` preserves all historical/prototype rows,
including superseded diagnostic runs. Select exact identities from build metadata
and never mix these rows into the final matrix. The first four prototype manifests
hash only 64 selected source files plus the harness; later manifests hash the full
Rust/manifest source set. `exploratory/snapshot-validation.json` records those
limits and verifies that the preserved snapshots match every recorded source hash.
