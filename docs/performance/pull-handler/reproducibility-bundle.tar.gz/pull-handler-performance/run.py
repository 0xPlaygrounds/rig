import json,subprocess,hashlib,sys,time
from pathlib import Path
R=Path(__file__).resolve().parent
variants=sys.argv[1].split(',')
filters=sys.argv[2:]
repetitions=5
if '--repetitions' in filters:
 i=filters.index('--repetitions');repetitions=int(filters[i+1]);del filters[i:i+2]
assert repetitions>0
plan=json.loads((R/'plan.json').read_text())
rows=[r for r in plan if not filters or any(f==r['name']for f in filters)]
assert rows
metas={v:json.loads((R/'results'/f'{v}-latest.json').read_text())for v in variants}
output=R/'results/samples.jsonl';completed=set()
if output.exists():
 for line in output.read_text().splitlines():
  s=json.loads(line);key=(s['identity'],s['config_sha256'],s['repetition']);assert key not in completed;completed.add(key)
for row in rows:
 config=R/'run-configs'/f"{row['name']}.json"
 cfg_hash=hashlib.sha256(config.read_bytes()).hexdigest()
 for rep in range(repetitions):
  for v in (variants if rep%2==0 else list(reversed(variants))):
   m=metas[v];key=(m['identity'],cfg_hash,rep)
   if key in completed:continue
   binary=R/'bin'/m['identity'];assert hashlib.sha256(binary.read_bytes()).hexdigest()==m['binary_sha256']
   start=time.time();p=subprocess.run([str(binary),str(config)],capture_output=True,text=True,timeout=90)
   if p.returncode:
    (R/'results'/f"failure-{m['identity']}-{row['name']}-{rep}.log").write_text(p.stderr+p.stdout)
    raise RuntimeError((v,row['name'],rep,p.returncode,p.stderr))
   s=json.loads(p.stdout);assert s['verified'];s.update(variant=v,identity=m['identity'],binary_sha256=m['binary_sha256'],config_sha256=cfg_hash,repetition=rep,started_unix=start,process_wall_s=time.time()-start)
   with output.open('a')as f:f.write(json.dumps(s,separators=(',',':'))+'\n')
   completed.add(key)
 print('Finished',row['name'],flush=True)
