# Experimental acceptance targets, set before candidate tuning

These targets apply to repeated release runs on this machine; they are not product SLAs or preemption guarantees. Compare refreshed reference measurements, report noise/spread and every tradeoff. Retain the original 88 workload inputs. Preserve the original experiment directory unchanged.

- Single ready ECS stream / 256 deltas: median completion <= 1 ms (historical 0.257 vs 6.952 ms).
- 64 ready ECS streams / 128 deltas / 60 Hz: median completion <= 100 ms (historical 23 vs 2,138 ms).
- OpenAI / 4 KiB chunks / 60 Hz: median completion <= 300 ms (historical 201 vs 5,269 ms).
- Heavy-verdict native workload: median of maximum whole-tick durations <= 8 ms (historical 0.327 vs 65.446 ms); investigate any individual run above 16 ms.
- 1,024 ready ECS streams: median maximum whole-tick duration <= 16 ms (historical 89 vs 12 ms). Do not restore unbounded collector draining.
- Paced 50-event/s streams: completion and p95 delivery latency within one host tick of the better reference. CPU gains may trade off against isolation/throughput, but must be reported; investigate CPU above 1.25x #2443.
- Sparse 4,096 streams / 1 kHz: investigate CPU above 1.25x #2443; avoid per-source polling without readiness if choosing executor driving.
- No unexplained >25% increase in full-work peak heap against the larger reference; distinguish source buffering, retained output, recorder and harness memory.
- Agent direct streams and layered recording: no repeatable >15% regression relative to original #2473. Writer work is measured separately; optimize only with preserved lifetime/bounds or explain the tradeoff.
- All exact output/correctness and lifecycle/replay gates pass. All queues and draining must be bounded; multiple quiescence passes must not defeat the chosen bound.

Prototype one bounded direct drain and one long-lived executor-driven stream with bounded private delivery. Initially use the same drain cap to distinguish thread placement/transport. Refine based on measurements; select a single default. If targets conflict, document the actual candidate results and unresolved acceptance decision rather than lowering targets silently.
