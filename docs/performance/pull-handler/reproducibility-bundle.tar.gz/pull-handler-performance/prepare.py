"""Reconstruct the measured sources from a local Rig clone; never change that clone."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def run(*args, cwd=None):
    subprocess.run(args, cwd=cwd, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repository", type=Path, help="Local clone containing both pinned revisions")
    args = parser.parse_args()
    repository = args.repository.resolve()
    refs = json.loads((ROOT / "references.json").read_text())
    selection = json.loads((ROOT / "results/final-selection.json").read_text())
    (ROOT / "sources").mkdir(exist_ok=True)
    (ROOT / "bin").mkdir(exist_ok=True)
    for variant in ("ref2443", "ref2473", "candidate1"):
        source = ROOT / "sources" / variant
        if source.exists():
            raise SystemExit(f"Refusing to overwrite {source}; use a fresh extracted bundle.")
        run("git", "clone", "--quiet", "--shared", "--no-checkout", str(repository), str(source))
        revision = refs["2443" if variant == "ref2443" else "2473"]
        run("git", "checkout", "--quiet", "--detach", revision, cwd=source)
        if variant == "candidate1":
            run("git", "apply", "--check", str(ROOT / "candidate1.patch"), cwd=source)
            run("git", "apply", str(ROOT / "candidate1.patch"), cwd=source)
            shutil.copytree(ROOT / "candidate-extra", source, dirs_exist_ok=True)
        shutil.copytree(ROOT / "harness", source / "examples/protocol_perf")
        shutil.copy2(ROOT / "locks" / f"{variant}.lock", source / "Cargo.lock")
        identity = selection["timing_identities"][variant]
        expected = json.loads((ROOT / "results" / f"{identity}.build.json").read_text())
        mismatches = [name for name, digest in expected["source_hashes"].items()
                      if not (source / name).is_file()
                      or hashlib.sha256((source / name).read_bytes()).hexdigest() != digest]
        if mismatches:
            raise SystemExit(f"Source identity mismatch for {variant}: {mismatches}")
        print(f"Verified every recorded source hash for {variant}", flush=True)
    configs = ROOT / "run-configs"
    configs.mkdir(exist_ok=True)
    for path in (ROOT / "configs").glob("*.json"):
        config = json.loads(path.read_text())
        if config.get("fixture"):
            config["fixture"] = str(ROOT / "fixtures" / Path(config["fixture"]).name)
        (configs / path.name).write_text(json.dumps(config, indent=2) + "\n")
    print("Prepared sources and relocated configs. Original archived configs remain unchanged.")


if __name__ == "__main__":
    main()
