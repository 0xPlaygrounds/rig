use super::*;
use bytes::Bytes;
use rig_core::{
    client::CompletionClient,
    completion::{CompletionError, CompletionModel},
    http_client::{
        self, HttpClientExt, LazyBody, MultipartForm, Request, Response, StatusCode,
        StreamingResponse, sse::BoxedStream,
    },
    providers::{anthropic, deepseek, openai},
    streaming::{StreamEvents, StreamingCompletionResponse},
    wasm_compat::WasmCompatSend,
};
#[derive(Clone)]
struct Replay {
    body: Bytes,
    shared: Arc<Shared>,
    last_due: Arc<AtomicU64>,
}
struct Chunks {
    replay: Replay,
    offset: usize,
    delay: Option<futures_timer::Delay>,
}
impl Stream for Chunks {
    type Item = Result<Bytes, http_client::Error>;
    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        if self.offset == self.replay.body.len() {
            return Poll::Ready(None);
        }
        let c = &self.replay.shared.cfg;
        let due = (self.offset / c.chunk) as u64 * c.interval_us * 1000;
        let now = self.replay.shared.elapsed();
        if now < due {
            let d = self
                .delay
                .get_or_insert_with(|| futures_timer::Delay::new(Duration::from_nanos(due - now)));
            if Pin::new(d).poll(cx).is_pending() {
                return Poll::Pending;
            }
        }
        self.delay = None;
        let end = (self.offset + self.replay.shared.cfg.chunk).min(self.replay.body.len());
        let bytes = self.replay.body.slice(self.offset..end);
        self.offset = end;
        self.replay.last_due.store(due, Relaxed);
        Poll::Ready(Some(Ok(bytes)))
    }
}
impl HttpClientExt for Replay {
    fn send<T, U>(
        &self,
        _: Request<T>,
    ) -> impl Future<Output = http_client::Result<Response<LazyBody<U>>>> + WasmCompatSend + 'static
    where
        T: Into<Bytes> + WasmCompatSend,
        U: From<Bytes> + WasmCompatSend + 'static,
    {
        std::future::ready(Err(http_client::Error::InvalidStatusCode(
            StatusCode::NOT_IMPLEMENTED,
        )))
    }
    fn send_multipart<U>(
        &self,
        _: Request<MultipartForm>,
    ) -> impl Future<Output = http_client::Result<Response<LazyBody<U>>>> + WasmCompatSend + 'static
    where
        U: From<Bytes> + WasmCompatSend + 'static,
    {
        std::future::ready(Err(http_client::Error::InvalidStatusCode(
            StatusCode::NOT_IMPLEMENTED,
        )))
    }
    fn send_streaming<T>(
        &self,
        _: Request<T>,
    ) -> impl Future<Output = http_client::Result<StreamingResponse>> + WasmCompatSend
    where
        T: Into<Bytes> + WasmCompatSend,
    {
        let body: BoxedStream = Box::pin(Chunks {
            replay: self.clone(),
            offset: 0,
            delay: None,
        });
        std::future::ready(
            Response::builder()
                .status(200)
                .header("content-type", "text/event-stream")
                .body(body)
                .map_err(http_client::Error::Protocol),
        )
    }
}
struct Tracked {
    inner: StreamEvents,
    guard: source::Source,
    last_due: Arc<AtomicU64>,
}
impl Stream for Tracked {
    type Item = Result<StreamEvent, ErrorReport>;
    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        let s = self.guard.shared.clone();
        let state = &s.states[self.guard.index];
        state.polls.fetch_add(1, Relaxed);
        state.waker.register(cx.waker());
        if s.start.get().is_none() {
            return Poll::Pending;
        }
        let item = self.inner.as_mut().poll_next(cx);
        if matches!(item, Poll::Ready(Some(_))) {
            state.due.lock().unwrap().push(self.last_due.load(Relaxed));
            state.emitted.lock().unwrap().push(s.elapsed());
            state.produced.fetch_add(1, Relaxed);
        }
        item
    }
}
#[derive(Clone)]
struct Model {
    shared: Arc<Shared>,
    body: Bytes,
}
impl CompletionModel for Model {
    async fn completion(
        &self,
        _: CompletionRequest,
    ) -> Result<CompletionResponse, CompletionError> {
        panic!("stream-only replay")
    }
    async fn stream(
        &self,
        mut request: CompletionRequest,
    ) -> Result<StreamingCompletionResponse, CompletionError> {
        let index = request.additional_params.take().unwrap()["index"]
            .as_u64()
            .unwrap() as usize;
        request.max_tokens = Some(1024);
        let last_due = Arc::new(AtomicU64::new(0));
        let http = Replay {
            body: self.body.clone(),
            shared: self.shared.clone(),
            last_due: last_due.clone(),
        };
        let inner: StreamEvents = match self.shared.cfg.provider.as_str() {
            "openai" => Box::pin(
                openai::Client::new_with("fixture-only", http)
                    .unwrap()
                    .completions_api()
                    .completion_model("gpt-4o")
                    .stream(request)
                    .await?,
            ),
            "anthropic" => Box::pin(
                anthropic::Client::new_with("fixture-only", http)
                    .unwrap()
                    .completion_model("claude-sonnet-4-5")
                    .stream(request)
                    .await?,
            ),
            "deepseek" => Box::pin(
                deepseek::Client::new_with("fixture-only", http)
                    .unwrap()
                    .completion_model("deepseek-reasoner")
                    .stream(request)
                    .await?,
            ),
            _ => panic!("provider"),
        };
        let tracked = Tracked {
            inner,
            guard: source::Source::new(self.shared.clone(), index),
            last_due,
        };
        Ok(StreamingCompletionResponse::from_events(
            "bench",
            Box::pin(tracked),
        ))
    }
}
pub fn handler(shared: Arc<Shared>) -> ErasedHandler {
    let body = Bytes::from(std::fs::read(&shared.cfg.fixture).unwrap());
    ErasedHandler::new(rig_core::serve::adapters::CompletionAdapter::new(
        "bench",
        Model { shared, body },
    ))
}
pub fn validate(c: &Config, seen: &[usize], digests: &[u64]) {
    let mut cfg = c.clone();
    cfg.concurrency = 1;
    cfg.interval_us = 0;
    let shared = Shared::new(cfg);
    shared.open();
    let model = Model {
        shared,
        body: Bytes::from(std::fs::read(&c.fixture).unwrap()),
    };
    let (count, digest) = futures::executor::block_on(async move {
        let mut stream = model.stream(request(0)).await.unwrap();
        let mut n = 0;
        let mut h = 14695981039346656037u64;
        while let Some(event) = stream.next().await {
            for b in serde_json::to_vec(&event.unwrap()).unwrap() {
                h = (h ^ b as u64).wrapping_mul(1099511628211);
            }
            n += 1;
        }
        (n, h)
    });
    for (i, n) in seen.iter().enumerate() {
        assert_eq!(*n, count, "provider event count");
        assert_eq!(digests[i], digest, "provider event content");
    }
}
