use super::*;
use futures::task::AtomicWaker;
use rig_core::effect::EffectId;
use rig_core::serve::{Decision, Intercept, Verdict};

pub struct State {
    pub waker: AtomicWaker,
    pub started: AtomicBool,
    pub dropped: AtomicBool,
    pub polls: AtomicU64,
    pub produced: AtomicUsize,
    pub emitted: Mutex<Vec<u64>>,
    pub due: Mutex<Vec<u64>>,
    pub drop_ns: AtomicU64,
}
impl State {
    pub fn new() -> Self {
        Self {
            waker: AtomicWaker::new(),
            started: AtomicBool::new(false),
            dropped: AtomicBool::new(false),
            polls: AtomicU64::new(0),
            produced: AtomicUsize::new(0),
            emitted: Mutex::new(Vec::new()),
            due: Mutex::new(Vec::new()),
            drop_ns: AtomicU64::new(0),
        }
    }
}
pub struct Shared {
    pub cfg: Config,
    pub start: OnceLock<Instant>,
    pub states: Vec<Arc<State>>,
}
impl Shared {
    pub fn new(cfg: Config) -> Arc<Self> {
        let n = cfg.concurrency;
        Arc::new(Self {
            cfg,
            start: OnceLock::new(),
            states: (0..n).map(|_| Arc::new(State::new())).collect(),
        })
    }
    pub fn open(&self) {
        self.start.set(Instant::now()).unwrap();
        for s in &self.states {
            s.waker.wake()
        }
    }
    pub fn elapsed(&self) -> u64 {
        self.start
            .get()
            .map_or(0, |s| s.elapsed().as_nanos() as u64)
    }
    pub fn produced(&self) -> usize {
        self.states.iter().map(|s| s.produced.load(Relaxed)).sum()
    }
    pub fn polls(&self) -> u64 {
        self.states.iter().map(|s| s.polls.load(Relaxed)).sum()
    }
    pub fn dropped(&self) -> usize {
        self.states
            .iter()
            .filter(|s| s.dropped.load(Relaxed))
            .count()
    }
}
pub struct Source {
    pub shared: Arc<Shared>,
    pub index: usize,
    pos: usize,
    delay: Option<futures_timer::Delay>,
}
impl Source {
    pub fn new(shared: Arc<Shared>, index: usize) -> Self {
        shared.states[index].started.store(true, Relaxed);
        Self {
            shared,
            index,
            pos: 0,
            delay: None,
        }
    }
    fn due(&self) -> u64 {
        let c = &self.shared.cfg;
        if c.workload == "sparse" && self.index % 64 != 0 {
            return 10_000_000_000;
        }
        if c.workload == "cancel_idle" {
            return 10_000_000_000;
        }
        let interval = if c.workload == "fairness" && self.index > 0 {
            20_000
        } else {
            c.interval_us
        };
        ((self.pos / c.burst.max(1)) as u64) * interval * 1000
    }
}
impl Drop for Source {
    fn drop(&mut self) {
        let s = &self.shared.states[self.index];
        s.drop_ns.store(self.shared.elapsed(), Relaxed);
        s.dropped.store(true, Relaxed);
    }
}
impl Stream for Source {
    type Item = Result<StreamEvent, ErrorReport>;
    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        let state = self.shared.states[self.index].clone();
        state.polls.fetch_add(1, Relaxed);
        state.waker.register(cx.waker());
        if self.shared.start.get().is_none() {
            return Poll::Pending;
        }
        let c = &self.shared.cfg;
        let count = if c.workload == "fairness" && self.index > 0 {
            4
        } else {
            c.events
        };
        if self.pos > count {
            return Poll::Ready(None);
        }
        let due = self.due();
        let now = self.shared.elapsed();
        if now < due {
            let remaining = Duration::from_nanos(due - now);
            let d = self
                .delay
                .get_or_insert_with(|| futures_timer::Delay::new(remaining));
            if Pin::new(d).poll(cx).is_pending() {
                return Poll::Pending;
            }
        }
        self.delay = None;
        let c = &self.shared.cfg;
        burn(if c.workload == "fairness" && self.index > 0 {
            0
        } else {
            c.cpu_iters
        });
        let event = if self.pos == count {
            StreamEvent::Final(StreamFinal::new("bench", Usage::new()))
        } else {
            StreamEvent::text(
                BlockId::minted(rig_core::streaming::MintKind::Text, 0),
                token(self.index, self.pos, c.payload),
            )
        };
        state.emitted.lock().unwrap().push(self.shared.elapsed());
        state.due.lock().unwrap().push(due);
        state.produced.fetch_add(1, Relaxed);
        self.pos += 1;
        Poll::Ready(Some(Ok(event)))
    }
}
pub fn token(i: usize, p: usize, size: usize) -> String {
    let mut s = format!("{i}:{p}|");
    while s.len() < size {
        s.push('x')
    }
    s
}
pub fn burn(n: usize) {
    let mut x = 0x123456789u64;
    for _ in 0..n {
        x = x.wrapping_mul(6364136223846793005).wrapping_add(1);
        std::hint::black_box(x);
    }
    std::hint::black_box(x);
}
pub struct Handler {
    pub shared: Arc<Shared>,
}
impl Handler {
    fn index(kind: &EffectKind) -> usize {
        match kind {
            EffectKind::Completion { request, .. } => {
                request.additional_params.as_ref().unwrap()["index"]
                    .as_u64()
                    .unwrap() as usize
            }
            _ => panic!("unexpected kind"),
        }
    }
    async fn unary(&self, index: usize) -> Outcome {
        let guard = Source::new(self.shared.clone(), index);
        futures::future::poll_fn(|cx| {
            let s = &self.shared.states[index];
            s.polls.fetch_add(1, Relaxed);
            s.waker.register(cx.waker());
            if self.shared.start.get().is_some() {
                Poll::Ready(())
            } else {
                Poll::Pending
            }
        })
        .await;
        burn(if self.shared.cfg.workload == "fairness" {
            0
        } else {
            self.shared.cfg.cpu_iters
        });
        drop(guard);
        Outcome::Completion(CompletionResponse::new(
            vec![AssistantContent::text("ok")],
            Usage::new(),
            "bench",
        ))
    }
}
impl Serve for Handler {
    type Family = rig_core::effect::family::Completion;
    fn descriptor(&self) -> HandlerDescriptor {
        HandlerDescriptor {
            key: HandlerKey::from("bench"),
            family: FamilyDescriptor::Completion {
                model: ModelRef::new("bench"),
                capabilities: ProviderCapabilities::default(),
            },
            layers: vec![],
        }
    }
    #[cfg(feature = "pull")]
    async fn serve(
        &self,
        kind: EffectKind,
        _: rig_core::serve::Dispatch,
    ) -> rig_core::serve::Reply {
        let i = Self::index(&kind);
        if kind.streams() {
            if self.shared.cfg.workload == "writer" {
                let mut source = Source::new(self.shared.clone(), i);
                rig_core::serve::Reply::written(move |mut out| async move {
                    while let Some(item) = source.next().await {
                        let result = match item {
                            Ok(event) => out.event(event).await,
                            Err(error) => out.error(error).await,
                        };
                        if result.is_err() {
                            return;
                        }
                    }
                })
            } else {
                rig_core::serve::Reply::Stream(Box::pin(Source::new(self.shared.clone(), i)))
            }
        } else {
            rig_core::serve::Reply::Outcome(Ok(self.unary(i).await))
        }
    }
    #[cfg(not(feature = "pull"))]
    async fn serve(&self, kind: EffectKind, mut sink: rig_core::serve::OutcomeSink) {
        let i = Self::index(&kind);
        if kind.streams() {
            let mut source = Source::new(self.shared.clone(), i);
            while let Some(item) = source.next().await {
                if sink.send(item).await.is_err() {
                    return;
                }
            }
        } else {
            sink.resolve(Ok(self.unary(i).await)).await;
        }
    }
}
pub struct Layer(pub usize);
impl Intercept for Layer {
    fn name(&self) -> String {
        format!("bench-{}", self.0)
    }
    async fn before(&self, _: EffectId, _: &EffectKind) -> Decision {
        burn(self.0);
        Decision::Proceed
    }
    async fn after(
        &self,
        _: EffectId,
        _: &EffectKind,
        _: &Result<Outcome, ErrorReport>,
    ) -> Verdict {
        burn(self.0);
        Verdict::Keep
    }
}
pub fn handler(shared: Arc<Shared>) -> ErasedHandler {
    let n = shared.cfg.layers;
    let cost = shared.cfg.layer_cpu;
    let mut h = ErasedHandler::new(Handler { shared });
    for _ in 0..n {
        h = h.layered(Layer(cost))
    }
    h
}
