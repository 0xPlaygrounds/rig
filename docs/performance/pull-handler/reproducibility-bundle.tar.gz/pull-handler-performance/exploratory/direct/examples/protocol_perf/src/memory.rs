#[cfg(feature = "alloc")]
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicI64, AtomicU64, Ordering::Relaxed};
static LIVE: AtomicI64 = AtomicI64::new(0);
static PEAK: AtomicI64 = AtomicI64::new(0);
static COUNT: AtomicU64 = AtomicU64::new(0);
static BYTES: AtomicU64 = AtomicU64::new(0);
#[cfg(feature = "alloc")]
struct Tracked;
#[cfg(feature = "alloc")]
fn add(n: usize) {
    COUNT.fetch_add(1, Relaxed);
    BYTES.fetch_add(n as u64, Relaxed);
    let live = LIVE.fetch_add(n as i64, Relaxed) + n as i64;
    PEAK.fetch_max(live, Relaxed);
}
#[cfg(feature = "alloc")]
unsafe impl GlobalAlloc for Tracked {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 {
        let p = unsafe { System.alloc(l) };
        if !p.is_null() {
            add(l.size())
        }
        p
    }
    unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 {
        let p = unsafe { System.alloc_zeroed(l) };
        if !p.is_null() {
            add(l.size())
        }
        p
    }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) {
        LIVE.fetch_sub(l.size() as i64, Relaxed);
        unsafe { System.dealloc(p, l) }
    }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, n: usize) -> *mut u8 {
        let q = unsafe { System.realloc(p, l, n) };
        if !q.is_null() {
            LIVE.fetch_sub(l.size() as i64, Relaxed);
            add(n)
        }
        q
    }
}
#[cfg(feature = "alloc")]
#[global_allocator]
static ALLOC: Tracked = Tracked;
#[derive(Clone, Copy)]
pub struct Snap {
    pub live: i64,
    pub count: u64,
    pub bytes: u64,
    pub cpu: f64,
}
pub fn snap() -> Snap {
    Snap {
        live: LIVE.load(Relaxed),
        count: COUNT.load(Relaxed),
        bytes: BYTES.load(Relaxed),
        cpu: cpu(),
    }
}
pub fn reset_peak() {
    PEAK.store(LIVE.load(Relaxed), Relaxed);
}
pub fn peak() -> i64 {
    PEAK.load(Relaxed)
}
pub fn usage() -> libc::rusage {
    let mut r = std::mem::MaybeUninit::uninit();
    assert_eq!(
        unsafe { libc::getrusage(libc::RUSAGE_SELF, r.as_mut_ptr()) },
        0
    );
    unsafe { r.assume_init() }
}
fn cpu() -> f64 {
    let r = usage();
    r.ru_utime.tv_sec as f64
        + r.ru_utime.tv_usec as f64 / 1e6
        + r.ru_stime.tv_sec as f64
        + r.ru_stime.tv_usec as f64 / 1e6
}
