#![recursion_limit = "256"]
mod memory;
mod provider;
mod source;
use bevy_ecs::prelude::*;
use futures::{Stream, StreamExt};
use rig_core::{
    completion::{
        CompletionRequest, CompletionResponse, Message, ModelRef, ProviderCapabilities, Usage,
    },
    effect::{EffectKind, FamilyDescriptor, HandlerDescriptor, HandlerKey, Outcome},
    error::ErrorReport,
    message::AssistantContent,
    serve::{ErasedHandler, Serve, ServingPolicy},
    streaming::{BlockId, Delta, StreamEvent, StreamFinal},
};
use rig_ecs::bus::{EffectOutcome, Handlers, PendingEffect, Streamed};
use serde::{Deserialize, Serialize};
use source::Shared;
use std::{
    future::Future,
    pin::Pin,
    sync::{
        Arc, Mutex, OnceLock,
        atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering::Relaxed},
    },
    task::{Context, Poll, Waker},
    time::{Duration, Instant},
};

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default)]
pub struct Config {
    pub name: String,
    pub driver: String,
    pub workload: String,
    pub concurrency: usize,
    pub events: usize,
    pub hz: u64,
    pub interval_us: u64,
    pub burst: usize,
    pub payload: usize,
    pub cpu_iters: usize,
    pub layers: usize,
    pub layer_cpu: usize,
    pub record: String,
    pub pause_ms: u64,
    pub capacity: usize,
    pub provider: String,
    pub chunk: usize,
    pub fixture: String,
}
impl Default for Config {
    fn default() -> Self {
        Self {
            name: "ready".into(),
            driver: "ecs".into(),
            workload: "ready".into(),
            concurrency: 1,
            events: 256,
            hz: 0,
            interval_us: 0,
            burst: 1,
            payload: 32,
            cpu_iters: 0,
            layers: 0,
            layer_cpu: 0,
            record: "off".into(),
            pause_ms: 0,
            capacity: 64,
            provider: String::new(),
            chunk: 1024,
            fixture: String::new(),
        }
    }
}
fn request(i: usize) -> CompletionRequest {
    CompletionRequest {
        model: None,
        chat_history: vec![Message::user("bench")],
        documents: vec![],
        tools: vec![],
        temperature: None,
        max_tokens: None,
        tool_choice: None,
        additional_params: Some(serde_json::json!({"index":i})),
        output_schema: None,
        record_telemetry_content: false,
    }
}
fn is_unary(c: &Config, i: usize) -> bool {
    c.workload == "unary" || (c.workload == "fairness" && i % 16 == 15)
}
fn check_unary(out: &Result<Outcome, ErrorReport>) {
    match out {
        Ok(Outcome::Completion(response)) => {
            assert_eq!(response.choice, vec![AssistantContent::text("ok")])
        }
        _ => panic!("unexpected unary result: {out:?}"),
    }
}
fn kind(i: usize, unary: bool) -> EffectKind {
    EffectKind::Completion {
        request: request(i),
        stream: !unary,
    }
}
fn recorder(c: &Config) -> Option<rig_effect_log::EffectLogRecorder> {
    match c.record.as_str() {
        "off" => None,
        "fold" => Some(rig_effect_log::EffectLogRecorder::new()),
        "events" => Some(rig_effect_log::EffectLogRecorder::keeping_stream_events()),
        _ => panic!("record mode"),
    }
}
fn policy(c: &Config) -> ServingPolicy {
    ServingPolicy {
        command_capacity: c.concurrency.max(16),
        stream_capacity: c.capacity,
        serial_per_handler: false,
    }
}
fn erased(s: Arc<Shared>) -> ErasedHandler {
    if s.cfg.workload == "provider" {
        provider::handler(s)
    } else {
        source::handler(s)
    }
}
struct Ecs {
    world: World,
    entities: Vec<Entity>,
    cursor: Vec<usize>,
}
struct Agent {
    dispatcher: Option<rig_agent::bus::Dispatcher>,
    thread: Option<std::thread::JoinHandle<()>>,
    streams: Vec<(usize, Option<rig_agent::bus::EffectStream>)>,
    pending: Vec<(usize, Option<rig_agent::bus::Pending>)>,
    fresh: Vec<(usize, StreamEvent)>,
    done: Vec<bool>,
}
enum Driver {
    Ecs(Ecs),
    Agent(Agent),
}
impl Driver {
    fn new(s: Arc<Shared>, rec: Option<rig_effect_log::EffectLogRecorder>) -> Self {
        let c = &s.cfg;
        if c.driver == "ecs" {
            let mut world = World::new();
            rig_ecs::bus::Bus::with_policy(policy(c)).install(&mut world);
            if let Some(rec) = rec {
                rig_ecs::bus::EffectLogResource::install(&mut world, rec);
            }
            Handlers::with(&mut world, |h| {
                h.register_erased("bench", erased(s.clone()))
            })
            .unwrap()
            .unwrap();
            rig_ecs::bus::run_to_quiescence(&mut world);
            Self::Ecs(Ecs {
                world,
                entities: vec![],
                cursor: vec![0; c.concurrency],
            })
        } else {
            let (dispatcher, registrar, mut driver) = rig_agent::bus::Bus::channel_with(policy(c));
            driver.register_erased("bench", erased(s.clone())).unwrap();
            if let Some(rec) = rec {
                driver.record_to(rec)
            }
            drop(registrar);
            let thread = std::thread::spawn(move || futures::executor::block_on(driver));
            Self::Agent(Agent {
                dispatcher: Some(dispatcher),
                thread: Some(thread),
                streams: vec![],
                pending: vec![],
                fresh: vec![],
                done: vec![false; c.concurrency],
            })
        }
    }
    fn dispatch(&mut self, c: &Config) {
        for i in 0..c.concurrency {
            let k = kind(i, is_unary(c, i));
            match self {
                Self::Ecs(e) => e
                    .entities
                    .push(e.world.spawn(PendingEffect::new("bench", k)).id()),
                Self::Agent(a) => {
                    if is_unary(c, i) {
                        a.pending.push((
                            i,
                            Some(
                                a.dispatcher
                                    .as_ref()
                                    .unwrap()
                                    .dispatch(&HandlerKey::from("bench"), k),
                            ),
                        ))
                    } else {
                        a.streams.push((
                            i,
                            Some(
                                a.dispatcher
                                    .as_ref()
                                    .unwrap()
                                    .dispatch_stream(&HandlerKey::from("bench"), k),
                            ),
                        ))
                    }
                }
            }
        }
    }
    fn advance(&mut self) {
        match self {
            Self::Ecs(e) => rig_ecs::bus::run_to_quiescence(&mut e.world),
            Self::Agent(a) => {
                a.fresh.clear();
                let mut cx = Context::from_waker(Waker::noop());
                for (i, p) in a.pending.iter_mut() {
                    if let Some(v) = p {
                        if let Poll::Ready(out) = Pin::new(v).poll(&mut cx) {
                            check_unary(&out);
                            a.done[*i] = true;
                            *p = None
                        }
                    }
                }
                for (i, p) in a.streams.iter_mut() {
                    if let Some(v) = p {
                        loop {
                            match Pin::new(&mut *v).poll_next(&mut cx) {
                                Poll::Ready(Some(item)) => a.fresh.push((*i, item.unwrap())),
                                Poll::Ready(None) => {
                                    a.done[*i] = true;
                                    *p = None;
                                    break;
                                }
                                Poll::Pending => break,
                            }
                        }
                    }
                }
            }
        }
    }
    fn observe(&mut self, stats: &mut Stats, s: &Shared) {
        let now = s.elapsed();
        match self {
            Self::Ecs(e) => {
                for (i, &entity) in e.entities.iter().enumerate() {
                    if let Some(out) = e.world.get::<EffectOutcome>(entity) {
                        assert!(out.0.is_ok(), "{:?}", out.0);
                        if stats.done[i] == 0 {
                            if is_unary(&s.cfg, i) {
                                check_unary(&out.0);
                            }
                            stats.done[i] = now;
                        }
                    }
                    if let Some(stream) = e.world.get::<Streamed>(entity) {
                        assert!(stream.errors.is_empty());
                        for event in &stream.events[e.cursor[i]..] {
                            stats.event(i, event, now, s);
                        }
                        e.cursor[i] = stream.events.len();
                    }
                }
            }
            Self::Agent(a) => {
                for (i, event) in &a.fresh {
                    stats.event(*i, event, now, s);
                }
                for (i, done) in a.done.iter().enumerate() {
                    if *done && stats.done[i] == 0 {
                        stats.done[i] = now;
                    }
                }
            }
        }
    }
    fn validate_completed(&self, c: &Config) {
        if let Self::Ecs(e) = self {
            for (i, &entity) in e.entities.iter().enumerate() {
                let Some(outcome) = e.world.get::<EffectOutcome>(entity) else {
                    continue;
                };
                if is_unary(c, i) {
                    check_unary(&outcome.0);
                    continue;
                }
                let streamed = e.world.get::<Streamed>(entity).unwrap();
                let mut fold = rig_core::serve::StreamTap::new();
                let mut expected = None;
                for event in &streamed.events {
                    let value = fold.observe(&Ok(event.clone()));
                    if expected.is_none() {
                        expected = value;
                    }
                }
                let expected = expected.expect("completed stream has a fold");
                assert_eq!(
                    serde_json::to_value(&outcome.0).unwrap(),
                    serde_json::to_value(&expected).unwrap()
                );
            }
        }
    }
    fn cancel(&mut self) {
        match self {
            Self::Ecs(e) => {
                for entity in e.entities.drain(..) {
                    e.world.despawn(entity);
                }
            }
            Self::Agent(a) => {
                a.streams.clear();
                a.pending.clear();
            }
        }
    }
}
impl Drop for Agent {
    fn drop(&mut self) {
        self.streams.clear();
        self.pending.clear();
        drop(self.dispatcher.take());
        self.thread.take().unwrap().join().unwrap();
    }
}
struct Stats {
    seen: Vec<usize>,
    done: Vec<u64>,
    latency: Vec<u64>,
    queue_latency: Vec<u64>,
    ticks: Vec<u64>,
    backlog: usize,
    checksums: Vec<u64>,
}
impl Stats {
    fn new(n: usize) -> Self {
        Self {
            seen: vec![0; n],
            done: vec![0; n],
            latency: vec![],
            queue_latency: vec![],
            ticks: vec![],
            backlog: 0,
            checksums: vec![14695981039346656037; n],
        }
    }
    fn event(&mut self, i: usize, event: &StreamEvent, now: u64, s: &Shared) {
        let p = self.seen[i];
        if s.cfg.workload != "provider" {
            let cap = if s.cfg.workload == "fairness" && i > 0 {
                4
            } else {
                s.cfg.events
            };
            if p == cap {
                assert_eq!(
                    *event,
                    StreamEvent::Final(StreamFinal::new("bench", Usage::new()))
                )
            } else {
                match event {
                    StreamEvent::BlockDelta {
                        id,
                        delta: Delta::Text { text },
                    } => {
                        assert_eq!(*id, BlockId::minted(rig_core::streaming::MintKind::Text, 0));
                        let (index, rest) = text.split_once(':').unwrap();
                        let (position, padding) = rest.split_once('|').unwrap();
                        assert_eq!(index.parse::<usize>().unwrap(), i);
                        assert_eq!(position.parse::<usize>().unwrap(), p);
                        assert!(padding.bytes().all(|b| b == b'x'));
                        assert!(text.len() >= s.cfg.payload);
                    }
                    _ => panic!("unexpected event"),
                }
            }
        }
        // Cheap output digest, checked against a reference for provider workloads.
        if s.cfg.workload == "provider" {
            for b in serde_json::to_vec(event).unwrap() {
                self.checksums[i] = (self.checksums[i] ^ b as u64).wrapping_mul(1099511628211);
            }
        } else if let StreamEvent::BlockDelta {
            delta: Delta::Text { text },
            ..
        } = event
        {
            for b in text.bytes() {
                self.checksums[i] = (self.checksums[i] ^ b as u64).wrapping_mul(1099511628211);
            }
        }
        let st = &s.states[i];
        let due = st.due.lock().unwrap()[p];
        let emitted = st.emitted.lock().unwrap()[p];
        self.latency.push(now.saturating_sub(due));
        self.queue_latency.push(now.saturating_sub(emitted));
        self.seen[i] += 1;
    }
}
fn quant(v: &[u64], q: f64) -> f64 {
    if v.is_empty() {
        return 0.0;
    }
    let mut s = v.to_vec();
    s.sort_unstable();
    s[((s.len() - 1) as f64 * q).round() as usize] as f64 / 1000.0
}
fn main() {
    let c: Config = serde_json::from_str(
        &std::fs::read_to_string(std::env::args().nth(1).expect("config path")).unwrap(),
    )
    .unwrap();
    bevy_tasks::IoTaskPool::get_or_init(|| {
        bevy_tasks::TaskPoolBuilder::new().num_threads(4).build()
    });
    let base = memory::snap();
    let s = Shared::new(c.clone());
    let rec = recorder(&c);
    let mut driver = Driver::new(s.clone(), rec.clone());
    let mut stats = Stats::new(c.concurrency);
    let setup = Instant::now();
    let unary = c.workload == "unary";
    if !unary {
        driver.dispatch(&c);
        while !s
            .states
            .iter()
            .all(|v| v.started.load(Relaxed) && v.polls.load(Relaxed) > 0)
        {
            driver.advance();
            assert!(setup.elapsed() < Duration::from_secs(30), "prime timeout");
            std::thread::sleep(Duration::from_micros(50));
        }
    }
    assert_eq!(
        s.produced(),
        0,
        "primed sources must not emit before release"
    );
    let prime_ms = setup.elapsed().as_secs_f64() * 1000.0;
    memory::reset_peak();
    let before = memory::snap();
    let polls_before = s.polls();
    s.open();
    if unary {
        driver.dispatch(&c)
    }
    let timed = *s.start.get().unwrap();
    let mut next_tick = timed;
    let cancel = c.workload.starts_with("cancel_") || c.workload == "sparse";
    let end_ms = if c.workload == "sparse" { 300 } else { 100 };
    let mut pause_produced = 0;
    let mut pause_delivered = 0;
    let mut pause_live = 0;
    let mut pause_captured = false;
    loop {
        let elapsed = timed.elapsed();
        assert!(
            elapsed < Duration::from_secs(60),
            "workload timeout {:?}, seen {:?}",
            c,
            stats.seen
        );
        if cancel && elapsed >= Duration::from_millis(end_ms) {
            break;
        }
        // Paused collection: ECS is not ticked; the agent consumer is not polled.
        let paused = c.pause_ms > 0 && elapsed < Duration::from_millis(c.pause_ms);
        if !paused || (c.workload == "slow_reads" && c.driver == "ecs") {
            if !paused && !pause_captured && c.pause_ms > 0 {
                pause_produced = s.produced();
                pause_delivered = stats.seen.iter().sum();
                pause_live = memory::snap().live;
                pause_captured = true;
            }
            let tick = Instant::now();
            driver.advance();
            stats.ticks.push(tick.elapsed().as_nanos() as u64);
            if !paused {
                driver.observe(&mut stats, &s);
            }
            stats.backlog = stats
                .backlog
                .max(s.produced().saturating_sub(stats.seen.iter().sum()));
            if stats.done.iter().all(|v| *v > 0) {
                break;
            }
        }
        if c.hz > 0 {
            next_tick += Duration::from_nanos(1_000_000_000 / c.hz);
            if let Some(wait) = next_tick.checked_duration_since(Instant::now()) {
                std::thread::sleep(wait)
            }
        } else if paused {
            std::thread::sleep(Duration::from_millis(1))
        } else {
            std::thread::yield_now()
        }
    }
    if c.pause_ms > 0 && !pause_captured {
        pause_produced = s.produced();
        pause_delivered = stats.seen.iter().sum();
        pause_live = memory::snap().live;
    }
    let wall = timed.elapsed().as_secs_f64();
    let after = memory::snap();
    let peak = memory::peak();
    let polls = s.polls() - polls_before;
    let produced = s.produced();
    driver.validate_completed(&c);
    let cancel_at = s.elapsed();
    let produced_at_cancel = s.produced();
    driver.cancel();
    let dropped_immediate = s.dropped();
    let drop_wait = Instant::now();
    while s.dropped() < c.concurrency {
        assert!(
            drop_wait.elapsed() < Duration::from_secs(10),
            "drop timeout"
        );
        std::thread::yield_now();
    }
    let after_cancel_produced = s.produced();
    let drop_latencies: Vec<_> = s
        .states
        .iter()
        .map(|v| v.drop_ns.load(Relaxed).saturating_sub(cancel_at))
        .collect();
    let seen: usize = stats.seen.iter().sum();
    if !cancel && c.workload != "provider" && !unary {
        for (i, &n) in stats.seen.iter().enumerate() {
            if is_unary(&c, i) {
                assert_eq!(n, 0);
                continue;
            }
            assert_eq!(
                n,
                if c.workload == "fairness" && i > 0 {
                    5
                } else {
                    c.events + 1
                }
            );
        }
    }
    if c.workload == "provider" {
        provider::validate(&c, &stats.seen, &stats.checksums);
    }
    let mut log_bytes = 0;
    let mut log_records = 0;
    let mut serialize_ms = 0.0;
    if let Some(rec) = &rec {
        let log = rec.log();
        log_records = log.records.len();
        let t = Instant::now();
        let serialized = serde_json::to_vec(&log).unwrap();
        serialize_ms = t.elapsed().as_secs_f64() * 1000.0;
        log_bytes = serialized.len();
        let decoded: rig_effect_log::EffectLog = serde_json::from_slice(&serialized).unwrap();
        rig_effect_log::EffectLogReplayer::check_header(&decoded).unwrap();
        if c.driver == "ecs" {
            let mut world = World::new();
            rig_ecs::bus::Bus::default().install(&mut world);
            Handlers::with(&mut world, |h| {
                rig_ecs::bus::Replay::default().register(h, &decoded)
            })
            .unwrap()
            .unwrap();
        }
    }
    drop(driver);
    drop(rec);
    let retained = memory::snap().live;
    let rss = memory::usage().ru_maxrss;
    println!(
        "{}",
        serde_json::json!({"config":c,"pull":cfg!(feature="pull"),"allocation_instrumented":cfg!(feature="alloc"),"prime_ms":prime_ms,"wall_ms":wall*1000.0,"cpu_ms":(after.cpu-before.cpu)*1000.0,"events":seen,"source_produced":produced,"source_polls":polls,"ticks":stats.ticks.len(),"tick_p50_us":quant(&stats.ticks,0.5),"tick_p95_us":quant(&stats.ticks,0.95),"tick_p99_us":quant(&stats.ticks,0.99),"tick_max_us":quant(&stats.ticks,1.0),"arrival_p50_us":quant(&stats.latency,0.5),"arrival_p95_us":quant(&stats.latency,0.95),"arrival_p99_us":quant(&stats.latency,0.99),"emission_to_consumer_p95_us":quant(&stats.queue_latency,0.95),"completion_p95_us":quant(&stats.done,0.95),"completion_by_effect_ns":stats.done,"max_source_ahead":stats.backlog,"pause_produced":pause_produced,"pause_delivered":pause_delivered,"pause_live_bytes":pause_live,"cancel_to_drop_p95_us":quant(&drop_latencies,0.95),"cancel_to_drop_max_us":quant(&drop_latencies,1.0),"dropped_immediately":dropped_immediate,"produced_after_cancel":after_cancel_produced.saturating_sub(produced_at_cancel),"allocations":after.count-before.count,"allocated_bytes":after.bytes-before.bytes,"allocations_including_setup":after.count-base.count,"allocated_bytes_including_setup":after.bytes-base.bytes,"live_phase_start_bytes":before.live,"live_phase_end_bytes":after.live,"peak_phase_bytes":peak,"peak_phase_growth_bytes":peak-before.live,"live_after_driver_drop_bytes":retained,"baseline_live_bytes":base.live,"rss_peak_native_units":rss,"log_bytes":log_bytes,"log_records":log_records,"log_serialize_ms":serialize_ms,"output_checksums":stats.checksums,"verified":true})
    );
}
