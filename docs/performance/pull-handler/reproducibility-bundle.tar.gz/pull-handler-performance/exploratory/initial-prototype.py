from pathlib import Path
R=Path(__file__).resolve().parent
for name in ['direct','executor']:
 root=R/'sources'/name
 p=root/'crates/rig-ecs/src/bus/collect.rs';s=p.read_text()
 s=s.replace('for (entity, Issued(id), mut streaming, mut streamed, publishing) in &mut streaming {',"'effects: for (entity, Issued(id), mut streaming, mut streamed, publishing) in &mut streaming {")
 start=s.index('        // One call to the outer stream')
 end=s.index('        let polled =',start)
 s=s[:start]+'''        // Prototype: at most 64 items per effect per Collect, without
        // treating deltas as progress. Quiescence retains its separate cap.
        for _ in 0..64 {
'''+s[end:]
 s=s.replace('Poll::Pending => continue,',"Poll::Pending => continue 'effects,")
 marker='''        progress.mark();
    }
}

/// The effect's delivery fold'''
 s=s.replace(marker,"""        progress.mark();
        continue 'effects;
        }
    }
}

/// The effect's delivery fold""")
 # Return the stream only after collection; borrow executions removal cannot
 # happen while stream borrowed across an enclosing loop, end on outcome.
 s=s.replace('let Some(stream) = executions.streams.get_mut(&entity) else {\n            continue;\n        };','')
 s=s.replace('        let polled = stream.as_mut().poll_next(&mut cx);','        let polled = executions.streams.get_mut(&entity).expect("owned stream").as_mut().poll_next(&mut cx);')
 p.write_text(s)
 if name=='executor':
  p=root/'crates/rig-ecs/Cargo.toml';s=p.read_text().replace('[dependencies]','[dependencies]\nfutures = { workspace = true }');p.write_text(s)
  p=root/'crates/rig-ecs/src/bus/dispatch.rs';s=p.read_text().replace('use bevy_tasks::IoTaskPool;','use bevy_tasks::IoTaskPool;\nuse futures::{SinkExt, StreamExt};\nuse rig_core::{serve::Reply, streaming::StreamEvents};')
  s=s.replace('''                let task =
                    IoTaskPool::get().spawn(async move { handler.handle(kind, dispatch).await });''','''                let streaming = effect.is_stream();
                let capacity = policy.stream_capacity.max(1);
                let task = IoTaskPool::get().spawn(async move {
                    let reply = handler.handle(kind, dispatch).await;
                    if !streaming {
                        return Reply::Outcome(reply.into_outcome().await);
                    }
                    match reply {
                        Reply::Stream(stream) => Reply::Stream(buffered(stream, capacity)),
                        outcome => outcome,
                    }
                });''')
  s+='''
/// Prototype bounded worker transport. Its task remains owned by the reply.
fn buffered(mut stream: StreamEvents, capacity: usize) -> StreamEvents {
    let (mut sender, mut receiver) = futures::channel::mpsc::channel(capacity);
    let task = IoTaskPool::get().spawn(async move {
        while let Some(item) = stream.next().await {
            if sender.send(item).await.is_err() { return; }
        }
    });
    Box::pin(futures::stream::poll_fn(move |cx| {
        let _owned_task = &task;
        receiver.poll_next_unpin(cx)
    }))
}
'''
  p.write_text(s)
