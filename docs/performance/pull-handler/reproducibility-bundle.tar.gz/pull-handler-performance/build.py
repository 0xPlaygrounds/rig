import subprocess,shutil,os,json,hashlib,sys
from pathlib import Path
R=Path(__file__).resolve().parent
allocation='--alloc' in sys.argv
diagnostic='--diagnostic' in sys.argv
latency='--latency' in sys.argv
assert not latency or not (allocation or diagnostic), 'latency diagnosis is a separate instrumentation mode'
harness=R/('latency-harness' if latency else 'harness')
variants=[arg for arg in sys.argv[1:] if arg not in ('--alloc','--diagnostic','--latency')] or ['direct','executor']
for name in variants:
 source=R/'sources'/name
 shutil.copytree(harness,source/'examples/protocol_perf',dirs_exist_ok=True)
 cmd=['cargo','build','--release','--offline','-p','protocol-perf']
 features=[]
 if name!='ref2443':features.append('pull')
 if allocation:features.append('alloc')
 if diagnostic:features.append('diagnostic')
 if features:cmd+=['--features',','.join(features)]
 variant=name+('-alloc' if allocation else '')+('-diagnostic' if diagnostic else '')+('-latency' if latency else '')
 env=os.environ|{'CARGO_TARGET_DIR':f'/tmp/rig-perf-followup-{name}-target'}
 with (R/'results'/f'build-{variant}.log').open('w')as log:subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 binary=Path(env['CARGO_TARGET_DIR'])/'release/protocol-perf'
 digest=hashlib.sha256(binary.read_bytes()).hexdigest();identity=variant+'-'+digest[:16]
 shutil.copy2(binary,R/'bin'/identity)
 files={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest()for p in source.rglob('*')if p.is_file() and p.suffix in ('.rs','.toml','.lock') and 'target' not in p.relative_to(source).parts}
 metadata={'command':cmd,'cwd':str(source),'target_dir':env['CARGO_TARGET_DIR'],'variant':variant,'allocation_instrumented':allocation,'diagnostic':diagnostic,'latency_diagnostic':latency,'identity':identity,'binary_sha256':digest,'source_hashes':files,'harness':{str(p.relative_to(harness)):hashlib.sha256(p.read_bytes()).hexdigest()for p in harness.rglob('*')if p.is_file()},'rustc':subprocess.check_output(['rustc','-Vv'],cwd=source,text=True)}
 (R/'results'/f'{identity}.build.json').write_text(json.dumps(metadata,indent=2)+'\n')
 (R/'results'/f'{variant}-latest.json').write_text(json.dumps(metadata,indent=2)+'\n')
 if latency:shutil.copytree(R/'harness',source/'examples/protocol_perf',dirs_exist_ok=True)
 print('Built',identity,flush=True)
